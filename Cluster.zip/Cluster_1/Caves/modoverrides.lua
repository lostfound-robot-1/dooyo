return {
  ["workshop-2119742489"]={
    configuration_options={ Hunger_Cost=1, Ownership=false, Sanity_Cost=1 },
    enabled=true 
  },
  ["workshop-2577742416"]={
    configuration_options={
      ENABLEPINGS=true,
      FIREOPTIONS=2,
      OVERRIDEMODE=false,
      SHAREMINIMAPPROGRESS=true,
      SHOWFIREICONS=true,
      SHOWPLAYERICONS=true,
      SHOWPLAYERSOPTIONS=2 
    },
    enabled=true 
  } 
}